#!/usr/bin/env python
# coding: utf-8

# In[1]:


#importing necessary libraries
# Working with data
import pandas as pd
import numpy as np
# Visualizations
import matplotlib.pyplot as plt
from matplotlib import rcParams
import seaborn as sns
get_ipython().run_line_magic('matplotlib', 'inline')
# Ignore warnings
import warnings
warnings.filterwarnings("ignore")


# In[2]:


#import the dataset
data=pd.read_csv('salarydata.csv')


# In[3]:


# Check the first five rows of the dataset
data.head()


# In[4]:


#Check the observations and features of the dataset
data.shape


# In[5]:


#Check the basic details of the dataset
data.info()


# In[6]:


data.describe()


# ### Handling missing values

# In[7]:


data.isna().sum()


# In[8]:


# replace the question mark in the dataset


# In[9]:


data = data.replace('?', np.nan)


# In[10]:


data.isna().sum()


# In[11]:


#replace the missing values with mode.


# In[12]:


data['workclass'].fillna(data['workclass'].mode()[0],inplace=True)
data['occupation'].fillna(data['occupation'].mode()[0],inplace=True)
data['native-country'].fillna(data['native-country'].mode()[0],inplace=True)


# In[13]:


data.isna().sum()


# ### Correlation Matrix

# In[14]:


corrmatrix = data.corr()
plt.subplots(figsize =(20,8))
sns.heatmap(corrmatrix, vmin =-.4,vmax=0.9,annot =True ,linewidth =.2)


# In[15]:


# Drop the unnecessary columns


# In[16]:


data.drop(['education-num','relationship','race','capital-gain','capital-loss','native-country'],axis=1, inplace=True)


# ## Exploratory Data Analysis

# ### Univariate Analysis

# In[17]:


data['salary'].value_counts().plot.pie(autopct='%.1f%%')
plt.title("Distribution of Salary")
plt.rcParams['figure.figsize'] = (10,5)
plt.show()


# In[18]:


rcParams['figure.figsize'] = 10,10
data[['age','hours-per-week']].hist()


# In[19]:


#pie chart showing the marital status
data['marital-status'].value_counts().plot(kind='pie')
plt.rcParams['figure.figsize']=(7,7)
plt.show()


# In[20]:


data['occupation'].value_counts().plot(kind='pie')
plt.rcParams['figure.figsize']=(7,7)
plt.show()


# In[21]:


plt.hist(data['workclass'])
plt.xlabel("Job Title")
plt.ylabel("count")
plt.xticks(rotation=45)
plt.show()


# In[22]:


plt.hist(data['education'])
plt.xlabel("education")
plt.ylabel("count")
plt.xticks(rotation=45)
plt.show()


# ### Bivariate Analysis

# In[23]:


plt.hist(data['workclass'])
plt.xlabel("workclass")
plt.ylabel("salary")
plt.xticks(rotation=45)
plt.show()


# In[24]:


plt.hist(data['education'])
plt.xlabel("education")
plt.ylabel("salary")
plt.xticks(rotation=45)
plt.show()


# In[25]:


plt.hist(data['occupation'])
plt.xlabel("occupation")
plt.ylabel("salary")
plt.xticks(rotation=45)
plt.show()


# In[26]:


plt.hist(data['occupation'])
plt.xlabel("occupation")
plt.ylabel("education")
plt.xticks(rotation=45)
plt.show()


# In[27]:


data['age'] = pd.cut(data['age'], bins = [0, 25, 50, 100], labels = ['Young', 'Adult', 'Old']) 
sns.countplot(x = 'age', hue = 'salary', data = data)


# In[28]:


plt.figure(figsize=(10,5))
plt.xticks(rotation=45)
sns.countplot(x = 'workclass', hue = 'salary', data = data)


# In[29]:


data['hours-per-week'] = pd.cut(data['hours-per-week'], 
                                   bins = [0, 30, 40, 100], 
                                   labels = ['Lesser Hours', 'Normal Hours', 'Extra Hours'])


# In[30]:


sns.countplot(x = 'hours-per-week', hue = 'salary', data = data)


# In[31]:


sns.countplot(x = 'sex', hue = 'salary', data = data)


# In[32]:


# scatterplot
colors = ['red', 'blue']
salary = ['<=50K','>50K']


# In[33]:


for i in range(2):
    x = data[data['salary'] == salary[i]]
    plt.scatter(x['workclass'], x['education'], c = colors[i], label=salary[i])
plt.xlabel("workclass")
plt.xticks(rotation=45)
plt.ylabel("education")
plt.legend()


# Here we change some of the columns in to categorical data for visualization.Therefore again we have to load the dataset for doing model building

# In[34]:


#import the dataset
data=pd.read_csv('salarydata.csv')


# In[35]:


data = data.replace('?', np.nan)


# In[36]:


data.isna().sum()


# In[37]:


data['workclass'].fillna(data['workclass'].mode()[0],inplace=True)
data['occupation'].fillna(data['occupation'].mode()[0],inplace=True)
data['native-country'].fillna(data['native-country'].mode()[0],inplace=True)


# In[38]:


data.isna().sum()


# In[39]:


# Drop the unnecessary columns
data.drop(['education-num','relationship','race','capital-gain','capital-loss','native-country'],axis=1, inplace=True)
data


# ## Outlier Handling

# In[40]:


num_col = data.select_dtypes(include=np.number).columns.tolist()
plt.figure(figsize=(20,30))

for i, variable in enumerate(num_col):
                     plt.subplot(10,10,i+1)
                     plt.boxplot(data[variable],whis=1.5)
                     plt.tight_layout()
                     plt.title(variable)


# In[41]:


for i in num_col:
    Q1=data[i].quantile(0.25) # 25th quantile
    Q3=data[i].quantile(0.75)  # 75th quantile
    IQR=Q3-Q1
    Lower_Whisker = Q1 - 1.5*IQR 
    Upper_Whisker = Q3 + 1.5*IQR
    data[i] = np.clip(data[i], Lower_Whisker, Upper_Whisker) 


# In[42]:


plt.figure(figsize=(20,30))

for i, variable in enumerate(num_col):
                     plt.subplot(10,10,i+1)
                     plt.boxplot(data[variable],whis=1.5)
                     plt.tight_layout()
                     plt.title(variable)


# ## Encoding
# ### Label Encoding

# In[43]:


# importing Libraries for label encoding
from sklearn import preprocessing
from sklearn.preprocessing import LabelEncoder


# In[44]:


le=LabelEncoder()


# In[45]:


#encoding categorical features of dataset


# In[46]:


data['workclass']=le.fit_transform(data['workclass'])
data['education']=le.fit_transform(data['education'])
data['marital-status']=le.fit_transform(data['marital-status'])
data['occupation']=le.fit_transform(data['occupation'])
data['sex']=le.fit_transform(data['sex'])
data['salary']=le.fit_transform(data['salary'])


# In[47]:


data.head()


# ## Model Training

# In[48]:


# Seperating the data into dependent and independent variables. Here we take Species as target or dependent variable.


# In[49]:


X=data.drop('salary',axis=1)
y=data['salary']


# In[50]:


# Splitting the dataset into the Training set and Test set
from sklearn.model_selection import train_test_split
X_train,X_test,y_train,y_test=train_test_split(X,y,test_size=0.2,random_state=42)


# ### 1. Logistic Regression

# In[51]:


#importing the libraries for logistic regression
from sklearn.linear_model import LogisticRegression
from sklearn import metrics


# In[52]:


# Instantiate learning model
log_reg=LogisticRegression()


# In[53]:


# Fitting the model
log_reg_model=log_reg.fit(X_train,y_train)
# Predicting the Test set results
log_reg_pred=log_reg_model.predict(X_test)


# In[54]:


#Evaluating Predictions
from sklearn.metrics import confusion_matrix,accuracy_score,recall_score,f1_score,precision_score
print('accuracy:',accuracy_score(y_test,log_reg_pred))
print('precision:',precision_score(y_test,log_reg_pred))
print('recall:',recall_score(y_test,log_reg_pred))
print("f1_score:",f1_score(y_test,log_reg_pred))


# In[55]:


ac_log = accuracy_score( y_test,log_reg_pred)


# In[56]:


# Confusion Matrix
confusion_matrix(y_test,log_reg_pred)


# ### Model 2-KNN Model

# In[57]:


# importing libraries for KNN model
from sklearn.neighbors import KNeighborsClassifier


# In[58]:


metric_k=[]
neighbors= range(3,15)

for k in neighbors:
    classifier= KNeighborsClassifier(n_neighbors=k)
    classifier= classifier.fit(X_train,y_train)
    y_pred_kNN= classifier.predict(X_test)
    acc=accuracy_score(y_test,y_pred_kNN)
    metric_k.append(acc)


# In[59]:


plt.plot(neighbors,metric_k,'o-')
plt.xlabel('k values')
plt.ylabel('Accuracies')
plt.grid()


# In[60]:


# Instantiate learning model
classifier= KNeighborsClassifier(n_neighbors=5)
# Fitting the model
classifier= classifier.fit(X_train,y_train)
# Predicting the Test set results
y_pred_kNN= classifier.predict(X_test)


# In[61]:


#Evaluating Predictions
from sklearn.metrics import confusion_matrix,accuracy_score,recall_score,f1_score,precision_score
print('accuracy:',accuracy_score(y_test,y_pred_kNN))
print('precision:',precision_score(y_test,y_pred_kNN))
print('recall:',recall_score(y_test,y_pred_kNN))
print("f1_score:",f1_score(y_test,y_pred_kNN))


# In[62]:


ac_knn=accuracy_score(y_test,y_pred_kNN)


# In[63]:


# Confusion Matrix
confusion_matrix(y_test,y_pred_kNN)


# ### Model 3- Support Vector Machine Model 

# In[64]:


# Importing libraries for SVM model


# In[65]:


from sklearn.svm import SVC


# In[66]:


#SVM with rbf kernel
# Instantiate learning model
svm_clf=SVC(kernel='rbf')
# Fitting the model
svm_clf=svm_clf.fit(X_train,y_train)
# Predicting the Test set results
y_pred_SVM=svm_clf.predict(X_test)


# In[67]:


#Evaluating Predictions
from sklearn.metrics import confusion_matrix,accuracy_score,recall_score,f1_score,precision_score
print('accuracy:',accuracy_score(y_test,y_pred_SVM))
print('precision:',precision_score(y_test,y_pred_SVM))
print('recall:',recall_score(y_test,y_pred_SVM))
print("f1_score:",f1_score(y_test,y_pred_SVM))


# In[68]:


ac_svm=accuracy_score(y_test,y_pred_SVM)


# In[69]:


# Confusion Matrix
confusion_matrix(y_test,y_pred_SVM)


# ### Model 4- Decision Tree Classifier

# In[70]:


# importing libraries for decision tree classifier


# In[71]:


from sklearn.tree import DecisionTreeClassifier


# In[72]:


# Instantiate learning model
dt_clf=DecisionTreeClassifier()
# Fitting the model
dt_clf=dt_clf.fit(X_train,y_train)
# Predicting the Test set results
y_pred_dt=dt_clf.predict(X_test)


# In[73]:


#Evaluating Predictions
from sklearn.metrics import confusion_matrix,accuracy_score,recall_score,f1_score,precision_score
print('accuracy:',accuracy_score(y_test,y_pred_dt))
print('precision:',precision_score(y_test,y_pred_dt))
print('recall:',recall_score(y_test,y_pred_dt))
print("f1_score:",f1_score(y_test,y_pred_dt))


# In[74]:


ac_dt=accuracy_score(y_test,y_pred_dt)


# In[75]:


# Confusion Matrix
confusion_matrix(y_test,y_pred_dt)


# ### Model 5- Random Forest Algorithm

# In[76]:


# importing libraries for random forest algorithm
from sklearn.ensemble import RandomForestClassifier
# Instantiate learning model
rf_clf=RandomForestClassifier()
# Fitting the model
rf_clf=rf_clf.fit(X_train,y_train)
# Predicting the Test set results
y_pred_rf=rf_clf.predict(X_test)


# In[77]:


#Evaluating Predictions
from sklearn.metrics import confusion_matrix,accuracy_score,recall_score,f1_score,precision_score
print('accuracy:',accuracy_score(y_test,y_pred_rf))
print('precision:',precision_score(y_test,y_pred_rf))
print('recall:',recall_score(y_test,y_pred_rf))
print("f1_score:",f1_score(y_test,y_pred_rf))


# In[78]:


ac_rf=accuracy_score(y_test,y_pred_rf)


# In[79]:


# Confusion Matrix
confusion_matrix(y_test,y_pred_rf)


# ### Model 6- Extreme Gradient Boosting (XGBoost)

# In[80]:


# Install
get_ipython().system('pip install xgboost')
# Import
import xgboost as xgb


# In[81]:


# modeling 
xgboost = xgb.XGBClassifier()
xgboost= xgboost.fit(X_train, y_train)
xgb_pred = xgboost.predict(X_test)


# In[82]:


#Evaluating Predictions
from sklearn.metrics import confusion_matrix,accuracy_score,recall_score,f1_score,precision_score
print('accuracy:',accuracy_score(y_test,xgb_pred))
print('precision:',precision_score(y_test,xgb_pred))
print('recall:',recall_score(y_test,xgb_pred))
print("f1_score:",f1_score(y_test,xgb_pred))


# In[83]:


ac_xgb=accuracy_score(y_test,xgb_pred)


# In[84]:


# Confusion Matrix
confusion_matrix(y_test,xgb_pred)


# ### Model 7- Gradient Boosting 

# In[85]:


from sklearn.ensemble import GradientBoostingClassifier
gb = GradientBoostingClassifier()
gb.fit(X_train,y_train)
gb_pred = gb.predict(X_test)


# In[86]:


print('accuracy:',accuracy_score(y_test,gb_pred))
print('precision:',precision_score(y_test,gb_pred))
print('recall:',recall_score(y_test,gb_pred))
print("f1_score:",f1_score(y_test,gb_pred))


# In[87]:


ac_gb=accuracy_score(y_test,gb_pred)


# In[88]:


# Confusion Matrix
confusion_matrix(y_test,gb_pred)


# ### Model prediction Accuracy table 

# In[89]:


from tabulate import tabulate
table = [['Model', 'Accuracy'], ['Logistic Regression',ac_log], ['KNN',ac_knn],['Decision tree',ac_dt],['Random Forest',ac_rf],['SVM',ac_svm],['XG Boost',ac_xgb],['Gradient Booster',ac_gb]]
print(tabulate(table,headers='firstrow',tablefmt='fancy_grid'))


# ### Fine Tuning

# In[90]:


from sklearn.model_selection import GridSearchCV
parameters = {'learning_rate':[0.15,0.1,0.05,0.01,0.005,0.001], 'n_estimators':[100,250,500,750,1000,1250,1500,1750]}

tuning = GridSearchCV(estimator =GradientBoostingClassifier(max_depth=4, min_samples_split=2, min_samples_leaf=1, subsample=1,max_features='sqrt', random_state=10), 
            param_grid = parameters, scoring='accuracy',n_jobs=4,cv=5)
tuning.fit(X_train,y_train)
tuning.best_params_, tuning.best_score_


# In[91]:


parameter2 = {'max_depth':[2,3,4,5,6,7] }
tuning = GridSearchCV(estimator =GradientBoostingClassifier(learning_rate=0.01,n_estimators=1750, min_samples_split=2, min_samples_leaf=1, subsample=1,max_features='sqrt', random_state=10), 
            param_grid = parameter2, scoring='accuracy',n_jobs=4,cv=5)
tuning.fit(X_train,y_train)
tuning.best_params_, tuning.best_score_


# In[92]:


from sklearn.ensemble import GradientBoostingClassifier
gb = GradientBoostingClassifier(learning_rate=0.01, n_estimators=1750,max_depth=5, min_samples_split=2, min_samples_leaf=1, subsample=1,max_features='sqrt', random_state=10)
gb.fit(X_train,y_train)
y_pred = gb.predict(X_test)


# In[93]:


from sklearn.metrics import confusion_matrix,accuracy_score,recall_score,f1_score,precision_score
print('accuracy:',accuracy_score(y_test,y_pred))
print('precision:',precision_score(y_test,y_pred))
print('recall:',recall_score(y_test,y_pred))
print("f1_score:",f1_score(y_test,y_pred))


# In[94]:


# save the model
import pickle
filename = 'final.pkl'
pickle.dump(gb, open(filename, 'wb'))

