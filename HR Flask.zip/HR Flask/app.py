from flask import Flask, render_template, request
import pickle

app = Flask(__name__)
# load the model
model = pickle.load(open('final.pkl', 'rb'))

@app.route('/')
def home():
    return render_template('index.html')


@app.route('/predict', methods=['POST', 'GET'])
def predict():
    age = float(request.form['age'])
    workclass = float(request.form['workclass'])
    education = float(request.form['education'])
    maritalstatus=float(request.form['marital-status'])
    occupation = float(request.form['occupation'])
    sex = float(request.form['sex'])
    hoursperweek = float(request.form['hours-per-week'])
    pred = model.predict([[age, workclass,education,maritalstatus,occupation,sex,hoursperweek]])[0]

    if (pred==0):
        result='less than or equal to 50k'
    elif (pred==1):
        result='greater than 50k'
    return render_template('index.html', prediction_text='Salary is {}'.format(result))



if __name__ == '__main__':
    app.run()